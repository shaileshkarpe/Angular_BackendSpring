export interface gender{

  gender:string

}

export interface state{

  state:string

}
