export class User{
    firstName!:string;
    lastName!:string;
    email!:string;
     birthdate!: string;
     address1!:string;
      address2!:string;
       city!:string;
        zipcode!:string;
         gender!:string;
}