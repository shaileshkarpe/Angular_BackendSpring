import { Component } from '@angular/core';
@Component({
    template: '<formio src="https://gmzefhsjaoausii.form.io/user/register"></formio>'
  })
export class MainComponent  {}
